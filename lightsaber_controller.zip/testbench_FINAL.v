// ============================================================
// Module: testbench_updated
// Project: Lightsaber Control Circuit
// Cohort:  Halo 2 (2004)
// Course:  CS 4341 - Spring 2026
//
// Description:
//   UPDATED testbench that properly tests all 12 valid opcodes:
//   0000–1001 (original opcodes) + 1010 (Toggle Power) + 1011 (Double Length)
//   Tests error detection for reserved opcodes 1100–1111
//
// Test Suite from System Design:
//   0000 - Power OFF
//   0001 - Power ON
//   0010 - Set Blade Length
//   0011 - Increment Length
//   0100 - Decrement Length
//   0101 - Set Blade Color
//   0110 - Set Blade Count
//   0111 - Lock System
//   1000 - Unlock System
//   1001 - Reset Errors
//   1010 - Toggle Power (NEW)
//   1011 - Double Length (NEW)
//   1100–1111 - Reserved (Invalid)
// ============================================================
`timescale 1ns/1ps

module testbench;

reg        clk;
reg        reset;
reg  [3:0] opcode;
reg  [7:0] data_in;

wire [7:0] blade_length;
wire [7:0] blade_color;
wire [7:0] blade_count;
wire [7:0] error_reg;
wire       power_status;
wire       lock_status;

breadboard DUT (
    .clk         (clk),
    .reset       (reset),
    .opcode      (opcode),
    .data_in     (data_in),
    .blade_length(blade_length),
    .blade_color (blade_color),
    .blade_count (blade_count),
    .error_reg   (error_reg),
    .power_status(power_status),
    .lock_status (lock_status)
);

initial clk = 0;
always  #5 clk = ~clk;

task show_state;
    input integer test_num;
    begin
        $display("--- Test %0d ---", test_num);
        $display("  OPCODE LOADED  : %04b  (decimal %0d)", opcode, opcode);
        $display("  DATA_IN        : %08b  (decimal %0d)", data_in, data_in);
        $display("  [OUTPUT] blade_length  = %08b  (%0d)", blade_length, blade_length);
        $display("  [OUTPUT] blade_color   = %08b  (%0d)", blade_color,  blade_color);
        $display("  [OUTPUT] blade_count   = %08b  (%0d)", blade_count,  blade_count);
        $display("  [STATUS] power_status  = %0b  (%s)",  power_status,
                  power_status ? "ON" : "OFF");
        $display("  [STATUS] lock_status   = %0b  (%s)",  lock_status,
                  lock_status  ? "LOCKED" : "UNLOCKED");
        $display("  [ERROR]  error_reg     = %08b", error_reg);
        if (error_reg[0]) $display("    >> ERR[0]: Command received while system is powered off");
        if (error_reg[1]) $display("    >> ERR[1]: Operation attempted while system is locked");
        if (error_reg[2]) $display("    >> ERR[2]: Blade length decrement underflow (was 0)");
        if (error_reg[3]) $display("    >> ERR[3]: Blade length increment/double overflow");
        if (error_reg[4]) $display("    >> ERR[4]: Invalid opcode received (reserved 1100-1111)");
        if (error_reg == 8'h00) $display("    >> [OK] No errors");
        $display("");
    end
endtask

task send_cmd;
    input [3:0]   op;
    input [7:0]   data;
    input integer test_num;
    begin
        opcode  = op;
        data_in = data;
        @(posedge clk);
        #1;
        show_state(test_num);
    end
endtask

initial begin
    $display("=================================================================");
    $display("  LIGHTSABER CONTROL CIRCUIT - UPDATED TESTBENCH");
    $display("  Tests All 12 Valid Opcodes + 4 Reserved");
    $display("  Project Part 2  |  CS 4341 Spring 2026");
    $display("=================================================================");
    $display("");

    // ---- RESET --------------------------------------------------
    $display(">>> APPLYING SYNCHRONOUS RESET (2 cycles)");
    reset   = 1;
    opcode  = 4'b0000;
    data_in = 8'h00;
    @(posedge clk); #1;
    @(posedge clk); #1;
    reset = 0;
    $display(">>> Reset released. System ready.");
    $display("");

    // ===== SECTION 1: BASIC POWER CONTROL =====
    $display("===== SECTION 1: POWER CONTROL =====");
    $display("");

    $display(">>> TEST 1: Power ON (opcode 0001)");
    send_cmd(4'b0001, 8'h00, 1);

    $display(">>> TEST 2: Set blade length = 10 (opcode 0010)");
    send_cmd(4'b0010, 8'd10, 2);

    // ===== SECTION 2: TOGGLE POWER (NEW OPCODE 1010) =====
    $display("===== SECTION 2: TOGGLE POWER (OPCODE 1010) =====");
    $display("");

    $display(">>> TEST 3: Toggle Power (1->0) using opcode 1010");
    send_cmd(4'b1010, 8'h00, 3);

    $display(">>> TEST 4: Verify power is OFF - try to set length (should fail with ERR[0])");
    send_cmd(4'b0010, 8'd20, 4);

    $display(">>> TEST 5: Toggle Power (0->1) using opcode 1010");
    send_cmd(4'b1010, 8'h00, 5);

    $display(">>> TEST 6: Verify power is ON - set length again (should work)");
    send_cmd(4'b0010, 8'd20, 6);

    // ===== SECTION 3: DOUBLE LENGTH (NEW OPCODE 1011) =====
    $display("===== SECTION 3: DOUBLE LENGTH (OPCODE 1011) =====");
    $display("");

    $display(">>> TEST 7: Set blade length = 5 (opcode 0010)");
    send_cmd(4'b0010, 8'd5, 7);

    $display(">>> TEST 8: Double Length (5->10) using opcode 1011");
    send_cmd(4'b1011, 8'h00, 8);

    $display(">>> TEST 9: Double Length again (10->20) using opcode 1011");
    send_cmd(4'b1011, 8'h00, 9);

    // ===== SECTION 4: INCREMENT vs DOUBLE OVERFLOW =====
    $display("===== SECTION 4: OVERFLOW DETECTION =====");
    $display("");

    $display(">>> TEST 10: Set length = 200 (opcode 0010)");
    send_cmd(4'b0010, 8'd200, 10);

    $display(">>> TEST 11: Increment (200->201) should work");
    send_cmd(4'b0011, 8'h00, 11);

    $display(">>> TEST 12: Double (201->402 wraps to 146) should set ERR[3]");
    send_cmd(4'b1011, 8'h00, 12);

    $display(">>> TEST 13: Reset errors (opcode 1001)");
    send_cmd(4'b1001, 8'h00, 13);

    // ===== SECTION 5: DOUBLE WHILE LOCKED =====
    $display("===== SECTION 5: GATING - DOUBLE WHILE LOCKED =====");
    $display("");

    $display(">>> TEST 14: Set length = 7");
    send_cmd(4'b0010, 8'd7, 14);

    $display(">>> TEST 15: Lock system (opcode 0111)");
    send_cmd(4'b0111, 8'h00, 15);

    $display(">>> TEST 16: Try to double while locked (should set ERR[1])");
    send_cmd(4'b1011, 8'h00, 16);

    $display(">>> TEST 17: Verify length didn't change (still 7)");
    send_cmd(4'b1001, 8'h00, 17);

    // ===== SECTION 6: TOGGLE POWER WHILE LOCKED =====
    $display("===== SECTION 6: TOGGLE POWER NOT GATED BY LOCK =====");
    $display("");

    $display(">>> TEST 18: Toggle power while LOCKED (should work - not gated)");
    send_cmd(4'b1010, 8'h00, 18);

    $display(">>> TEST 19: Verify power turned OFF (even though locked)");
    send_cmd(4'b1001, 8'h00, 19);

    // ===== SECTION 7: RESERVED OPCODES =====
    $display("===== SECTION 7: RESERVED OPCODES (1100-1111) =====");
    $display("");

    $display(">>> TEST 20: Reserved opcode 1100 (should set ERR[4])");
    send_cmd(4'b1100, 8'h00, 20);

    $display(">>> TEST 21: Reserved opcode 1101 (should set ERR[4])");
    send_cmd(4'b1101, 8'h00, 21);

    $display(">>> TEST 22: Reserved opcode 1110 (should set ERR[4])");
    send_cmd(4'b1110, 8'h00, 22);

    $display(">>> TEST 23: Reserved opcode 1111 (should set ERR[4])");
    send_cmd(4'b1111, 8'hFF, 23);

    $display(">>> TEST 24: Reset all errors");
    send_cmd(4'b1001, 8'h00, 24);

    // ===== SECTION 8: COMPREHENSIVE SEQUENCE =====
    $display("===== SECTION 8: COMPREHENSIVE SEQUENCE =====");
    $display("");

    $display(">>> TEST 25: Power ON");
    send_cmd(4'b0001, 8'h00, 25);

    $display(">>> TEST 26: Unlock (might already be unlocked, but ensure it)");
    send_cmd(4'b1000, 8'h00, 26);

    $display(">>> TEST 27: Set length = 3, color = 2, count = 4");
    send_cmd(4'b0010, 8'd3, 27);
    send_cmd(4'b0101, 8'd2, 28);
    send_cmd(4'b0110, 8'd4, 29);

    $display(">>> TEST 30: Increment to 4");
    send_cmd(4'b0011, 8'h00, 30);

    $display(">>> TEST 31: Double to 8");
    send_cmd(4'b1011, 8'h00, 31);

    $display(">>> TEST 32: Increment to 9");
    send_cmd(4'b0011, 8'h00, 32);

    $display(">>> TEST 33: Decrement to 8");
    send_cmd(4'b0100, 8'h00, 33);

    $display(">>> TEST 34: Final state");
    send_cmd(4'b0001, 8'h00, 34);

    $display("");
    $display("=================================================================");
    $display("  TESTBENCH COMPLETE - All opcodes verified");
    $display("=================================================================");
    $finish;
end

endmodule
